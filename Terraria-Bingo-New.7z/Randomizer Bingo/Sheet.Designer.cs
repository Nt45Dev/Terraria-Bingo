﻿namespace Randomizer_Bingo
{
    partial class Sheet
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.B1 = new System.Windows.Forms.Button();
            this.I1 = new System.Windows.Forms.Button();
            this.N1 = new System.Windows.Forms.Button();
            this.G1 = new System.Windows.Forms.Button();
            this.O1 = new System.Windows.Forms.Button();
            this.O2 = new System.Windows.Forms.Button();
            this.G2 = new System.Windows.Forms.Button();
            this.N2 = new System.Windows.Forms.Button();
            this.I2 = new System.Windows.Forms.Button();
            this.B2 = new System.Windows.Forms.Button();
            this.O3 = new System.Windows.Forms.Button();
            this.G3 = new System.Windows.Forms.Button();
            this.N3 = new System.Windows.Forms.Button();
            this.I3 = new System.Windows.Forms.Button();
            this.B3 = new System.Windows.Forms.Button();
            this.O4 = new System.Windows.Forms.Button();
            this.G4 = new System.Windows.Forms.Button();
            this.N4 = new System.Windows.Forms.Button();
            this.I4 = new System.Windows.Forms.Button();
            this.B4 = new System.Windows.Forms.Button();
            this.O5 = new System.Windows.Forms.Button();
            this.G5 = new System.Windows.Forms.Button();
            this.N5 = new System.Windows.Forms.Button();
            this.I5 = new System.Windows.Forms.Button();
            this.B5 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.currentbingoslbl = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.sheetclipbtn = new System.Windows.Forms.PictureBox();
            this.copyseedlbl = new System.Windows.Forms.Label();
            this.seedtxtbx = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.sheetclipbtn)).BeginInit();
            this.SuspendLayout();
            // 
            // B1
            // 
            this.B1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.B1.BackColor = System.Drawing.SystemColors.Control;
            this.B1.Location = new System.Drawing.Point(22, 19);
            this.B1.Margin = new System.Windows.Forms.Padding(2);
            this.B1.Name = "B1";
            this.B1.Size = new System.Drawing.Size(175, 150);
            this.B1.TabIndex = 0;
            this.B1.Text = "B1";
            this.B1.UseVisualStyleBackColor = true;
            this.B1.Click += new System.EventHandler(this.B1_Click);
            // 
            // I1
            // 
            this.I1.Location = new System.Drawing.Point(196, 19);
            this.I1.Margin = new System.Windows.Forms.Padding(2);
            this.I1.Name = "I1";
            this.I1.Size = new System.Drawing.Size(175, 150);
            this.I1.TabIndex = 1;
            this.I1.Text = "I1";
            this.I1.UseVisualStyleBackColor = true;
            this.I1.Click += new System.EventHandler(this.I1_Click);
            // 
            // N1
            // 
            this.N1.Location = new System.Drawing.Point(370, 19);
            this.N1.Margin = new System.Windows.Forms.Padding(2);
            this.N1.Name = "N1";
            this.N1.Size = new System.Drawing.Size(175, 150);
            this.N1.TabIndex = 2;
            this.N1.Text = "N1";
            this.N1.UseVisualStyleBackColor = true;
            this.N1.Click += new System.EventHandler(this.N1_Click);
            // 
            // G1
            // 
            this.G1.Location = new System.Drawing.Point(543, 19);
            this.G1.Margin = new System.Windows.Forms.Padding(2);
            this.G1.Name = "G1";
            this.G1.Size = new System.Drawing.Size(175, 150);
            this.G1.TabIndex = 3;
            this.G1.Text = "G1";
            this.G1.UseVisualStyleBackColor = true;
            this.G1.Click += new System.EventHandler(this.G1_Click);
            // 
            // O1
            // 
            this.O1.Location = new System.Drawing.Point(717, 19);
            this.O1.Margin = new System.Windows.Forms.Padding(2);
            this.O1.Name = "O1";
            this.O1.Size = new System.Drawing.Size(175, 150);
            this.O1.TabIndex = 4;
            this.O1.Text = "O1";
            this.O1.UseVisualStyleBackColor = true;
            this.O1.Click += new System.EventHandler(this.O1_Click);
            // 
            // O2
            // 
            this.O2.Location = new System.Drawing.Point(717, 168);
            this.O2.Margin = new System.Windows.Forms.Padding(2);
            this.O2.Name = "O2";
            this.O2.Size = new System.Drawing.Size(175, 150);
            this.O2.TabIndex = 9;
            this.O2.Text = "O2";
            this.O2.UseVisualStyleBackColor = true;
            this.O2.Click += new System.EventHandler(this.O2_Click);
            // 
            // G2
            // 
            this.G2.Location = new System.Drawing.Point(543, 168);
            this.G2.Margin = new System.Windows.Forms.Padding(2);
            this.G2.Name = "G2";
            this.G2.Size = new System.Drawing.Size(175, 150);
            this.G2.TabIndex = 8;
            this.G2.Text = "G2";
            this.G2.UseVisualStyleBackColor = true;
            this.G2.Click += new System.EventHandler(this.G2_Click);
            // 
            // N2
            // 
            this.N2.Location = new System.Drawing.Point(370, 168);
            this.N2.Margin = new System.Windows.Forms.Padding(2);
            this.N2.Name = "N2";
            this.N2.Size = new System.Drawing.Size(175, 150);
            this.N2.TabIndex = 7;
            this.N2.Text = "N2";
            this.N2.UseVisualStyleBackColor = true;
            this.N2.Click += new System.EventHandler(this.N2_Click);
            // 
            // I2
            // 
            this.I2.Location = new System.Drawing.Point(196, 168);
            this.I2.Margin = new System.Windows.Forms.Padding(2);
            this.I2.Name = "I2";
            this.I2.Size = new System.Drawing.Size(175, 150);
            this.I2.TabIndex = 6;
            this.I2.Text = "I2";
            this.I2.UseVisualStyleBackColor = true;
            this.I2.Click += new System.EventHandler(this.I2_Click);
            // 
            // B2
            // 
            this.B2.Location = new System.Drawing.Point(22, 168);
            this.B2.Margin = new System.Windows.Forms.Padding(2);
            this.B2.Name = "B2";
            this.B2.Size = new System.Drawing.Size(175, 150);
            this.B2.TabIndex = 5;
            this.B2.Text = "B2";
            this.B2.UseVisualStyleBackColor = true;
            this.B2.Click += new System.EventHandler(this.B2_Click);
            // 
            // O3
            // 
            this.O3.Location = new System.Drawing.Point(717, 317);
            this.O3.Margin = new System.Windows.Forms.Padding(2);
            this.O3.Name = "O3";
            this.O3.Size = new System.Drawing.Size(175, 150);
            this.O3.TabIndex = 14;
            this.O3.Text = "O3";
            this.O3.UseVisualStyleBackColor = true;
            this.O3.Click += new System.EventHandler(this.O3_Click);
            // 
            // G3
            // 
            this.G3.Location = new System.Drawing.Point(543, 317);
            this.G3.Margin = new System.Windows.Forms.Padding(2);
            this.G3.Name = "G3";
            this.G3.Size = new System.Drawing.Size(175, 150);
            this.G3.TabIndex = 13;
            this.G3.Text = "G3";
            this.G3.UseVisualStyleBackColor = true;
            this.G3.Click += new System.EventHandler(this.G3_Click);
            // 
            // N3
            // 
            this.N3.Location = new System.Drawing.Point(370, 317);
            this.N3.Margin = new System.Windows.Forms.Padding(2);
            this.N3.Name = "N3";
            this.N3.Size = new System.Drawing.Size(175, 150);
            this.N3.TabIndex = 12;
            this.N3.Text = "N3";
            this.N3.UseVisualStyleBackColor = true;
            this.N3.Click += new System.EventHandler(this.N3_Click);
            // 
            // I3
            // 
            this.I3.Location = new System.Drawing.Point(196, 317);
            this.I3.Margin = new System.Windows.Forms.Padding(2);
            this.I3.Name = "I3";
            this.I3.Size = new System.Drawing.Size(175, 150);
            this.I3.TabIndex = 11;
            this.I3.Text = "I3";
            this.I3.UseVisualStyleBackColor = true;
            this.I3.Click += new System.EventHandler(this.I3_Click);
            // 
            // B3
            // 
            this.B3.Location = new System.Drawing.Point(22, 317);
            this.B3.Margin = new System.Windows.Forms.Padding(2);
            this.B3.Name = "B3";
            this.B3.Size = new System.Drawing.Size(175, 150);
            this.B3.TabIndex = 10;
            this.B3.Text = "B3";
            this.B3.UseVisualStyleBackColor = true;
            this.B3.Click += new System.EventHandler(this.B3_Click);
            // 
            // O4
            // 
            this.O4.Location = new System.Drawing.Point(717, 466);
            this.O4.Margin = new System.Windows.Forms.Padding(2);
            this.O4.Name = "O4";
            this.O4.Size = new System.Drawing.Size(175, 150);
            this.O4.TabIndex = 19;
            this.O4.Text = "O4";
            this.O4.UseVisualStyleBackColor = true;
            this.O4.Click += new System.EventHandler(this.O4_Click);
            // 
            // G4
            // 
            this.G4.Location = new System.Drawing.Point(543, 466);
            this.G4.Margin = new System.Windows.Forms.Padding(2);
            this.G4.Name = "G4";
            this.G4.Size = new System.Drawing.Size(175, 150);
            this.G4.TabIndex = 18;
            this.G4.Text = "G4";
            this.G4.UseVisualStyleBackColor = true;
            this.G4.Click += new System.EventHandler(this.G4_Click);
            // 
            // N4
            // 
            this.N4.Location = new System.Drawing.Point(370, 466);
            this.N4.Margin = new System.Windows.Forms.Padding(2);
            this.N4.Name = "N4";
            this.N4.Size = new System.Drawing.Size(175, 150);
            this.N4.TabIndex = 17;
            this.N4.Text = "N4";
            this.N4.UseVisualStyleBackColor = true;
            this.N4.Click += new System.EventHandler(this.N4_Click);
            // 
            // I4
            // 
            this.I4.Location = new System.Drawing.Point(196, 466);
            this.I4.Margin = new System.Windows.Forms.Padding(2);
            this.I4.Name = "I4";
            this.I4.Size = new System.Drawing.Size(175, 150);
            this.I4.TabIndex = 16;
            this.I4.Text = "I4";
            this.I4.UseVisualStyleBackColor = true;
            this.I4.Click += new System.EventHandler(this.I4_Click);
            // 
            // B4
            // 
            this.B4.Location = new System.Drawing.Point(22, 466);
            this.B4.Margin = new System.Windows.Forms.Padding(2);
            this.B4.Name = "B4";
            this.B4.Size = new System.Drawing.Size(175, 150);
            this.B4.TabIndex = 15;
            this.B4.Text = "B4";
            this.B4.UseVisualStyleBackColor = true;
            this.B4.Click += new System.EventHandler(this.B4_Click);
            // 
            // O5
            // 
            this.O5.Location = new System.Drawing.Point(717, 614);
            this.O5.Margin = new System.Windows.Forms.Padding(2);
            this.O5.Name = "O5";
            this.O5.Size = new System.Drawing.Size(175, 150);
            this.O5.TabIndex = 24;
            this.O5.Text = "O5";
            this.O5.UseVisualStyleBackColor = true;
            this.O5.Click += new System.EventHandler(this.O5_Click);
            // 
            // G5
            // 
            this.G5.Location = new System.Drawing.Point(543, 614);
            this.G5.Margin = new System.Windows.Forms.Padding(2);
            this.G5.Name = "G5";
            this.G5.Size = new System.Drawing.Size(175, 150);
            this.G5.TabIndex = 23;
            this.G5.Text = "G5";
            this.G5.UseVisualStyleBackColor = true;
            this.G5.Click += new System.EventHandler(this.G5_Click);
            // 
            // N5
            // 
            this.N5.Location = new System.Drawing.Point(370, 614);
            this.N5.Margin = new System.Windows.Forms.Padding(2);
            this.N5.Name = "N5";
            this.N5.Size = new System.Drawing.Size(175, 150);
            this.N5.TabIndex = 22;
            this.N5.Text = "N5";
            this.N5.UseVisualStyleBackColor = true;
            this.N5.Click += new System.EventHandler(this.N5_Click);
            // 
            // I5
            // 
            this.I5.Location = new System.Drawing.Point(196, 614);
            this.I5.Margin = new System.Windows.Forms.Padding(2);
            this.I5.Name = "I5";
            this.I5.Size = new System.Drawing.Size(175, 150);
            this.I5.TabIndex = 21;
            this.I5.Text = "I5";
            this.I5.UseVisualStyleBackColor = true;
            this.I5.Click += new System.EventHandler(this.I5_Click);
            // 
            // B5
            // 
            this.B5.Location = new System.Drawing.Point(22, 614);
            this.B5.Margin = new System.Windows.Forms.Padding(2);
            this.B5.Name = "B5";
            this.B5.Size = new System.Drawing.Size(175, 150);
            this.B5.TabIndex = 20;
            this.B5.Text = "B5";
            this.B5.UseVisualStyleBackColor = true;
            this.B5.Click += new System.EventHandler(this.B5_Click);
            // 
            // button1
            // 
            this.button1.Enabled = false;
            this.button1.Location = new System.Drawing.Point(22, 0);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(175, 20);
            this.button1.TabIndex = 25;
            this.button1.Text = "B";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Enabled = false;
            this.button2.Location = new System.Drawing.Point(196, 0);
            this.button2.Margin = new System.Windows.Forms.Padding(2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(175, 20);
            this.button2.TabIndex = 26;
            this.button2.Text = "I";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Enabled = false;
            this.button3.Location = new System.Drawing.Point(370, 0);
            this.button3.Margin = new System.Windows.Forms.Padding(2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(175, 20);
            this.button3.TabIndex = 27;
            this.button3.Text = "N";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Enabled = false;
            this.button4.Location = new System.Drawing.Point(543, 0);
            this.button4.Margin = new System.Windows.Forms.Padding(2);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(175, 20);
            this.button4.TabIndex = 28;
            this.button4.Text = "G";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Enabled = false;
            this.button5.Location = new System.Drawing.Point(717, 0);
            this.button5.Margin = new System.Windows.Forms.Padding(2);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(175, 20);
            this.button5.TabIndex = 29;
            this.button5.Text = "O";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.Enabled = false;
            this.button6.Location = new System.Drawing.Point(0, 19);
            this.button6.Margin = new System.Windows.Forms.Padding(2);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(24, 150);
            this.button6.TabIndex = 30;
            this.button6.Text = "1";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.Enabled = false;
            this.button7.Location = new System.Drawing.Point(0, 168);
            this.button7.Margin = new System.Windows.Forms.Padding(2);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(24, 150);
            this.button7.TabIndex = 31;
            this.button7.Text = "2";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.Enabled = false;
            this.button8.Location = new System.Drawing.Point(0, 317);
            this.button8.Margin = new System.Windows.Forms.Padding(2);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(24, 150);
            this.button8.TabIndex = 32;
            this.button8.Text = "3";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button9
            // 
            this.button9.Enabled = false;
            this.button9.Location = new System.Drawing.Point(0, 466);
            this.button9.Margin = new System.Windows.Forms.Padding(2);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(24, 150);
            this.button9.TabIndex = 33;
            this.button9.Text = "4";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button10
            // 
            this.button10.Enabled = false;
            this.button10.Location = new System.Drawing.Point(0, 614);
            this.button10.Margin = new System.Windows.Forms.Padding(2);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(24, 150);
            this.button10.TabIndex = 34;
            this.button10.Text = "5";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // currentbingoslbl
            // 
            this.currentbingoslbl.AutoSize = true;
            this.currentbingoslbl.Location = new System.Drawing.Point(106, 766);
            this.currentbingoslbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.currentbingoslbl.Name = "currentbingoslbl";
            this.currentbingoslbl.Size = new System.Drawing.Size(43, 15);
            this.currentbingoslbl.TabIndex = 35;
            this.currentbingoslbl.Text = "Bingos";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 766);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 15);
            this.label1.TabIndex = 36;
            this.label1.Text = "Current Bingos:";
            // 
            // sheetclipbtn
            // 
            this.sheetclipbtn.Location = new System.Drawing.Point(856, 771);
            this.sheetclipbtn.Margin = new System.Windows.Forms.Padding(2);
            this.sheetclipbtn.Name = "sheetclipbtn";
            this.sheetclipbtn.Size = new System.Drawing.Size(36, 36);
            this.sheetclipbtn.TabIndex = 37;
            this.sheetclipbtn.TabStop = false;
            this.sheetclipbtn.Click += new System.EventHandler(this.sheetclipbtn_Click);
            // 
            // copyseedlbl
            // 
            this.copyseedlbl.AutoSize = true;
            this.copyseedlbl.Location = new System.Drawing.Point(766, 766);
            this.copyseedlbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.copyseedlbl.Name = "copyseedlbl";
            this.copyseedlbl.Size = new System.Drawing.Size(63, 15);
            this.copyseedlbl.TabIndex = 38;
            this.copyseedlbl.Text = "Copy Seed";
            // 
            // seedtxtbx
            // 
            this.seedtxtbx.Location = new System.Drawing.Point(747, 784);
            this.seedtxtbx.Name = "seedtxtbx";
            this.seedtxtbx.Size = new System.Drawing.Size(100, 23);
            this.seedtxtbx.TabIndex = 39;
            // 
            // Sheet
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(895, 815);
            this.Controls.Add(this.seedtxtbx);
            this.Controls.Add(this.copyseedlbl);
            this.Controls.Add(this.sheetclipbtn);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.currentbingoslbl);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.O5);
            this.Controls.Add(this.G5);
            this.Controls.Add(this.N5);
            this.Controls.Add(this.I5);
            this.Controls.Add(this.B5);
            this.Controls.Add(this.O4);
            this.Controls.Add(this.G4);
            this.Controls.Add(this.N4);
            this.Controls.Add(this.I4);
            this.Controls.Add(this.B4);
            this.Controls.Add(this.O3);
            this.Controls.Add(this.G3);
            this.Controls.Add(this.N3);
            this.Controls.Add(this.I3);
            this.Controls.Add(this.B3);
            this.Controls.Add(this.O2);
            this.Controls.Add(this.G2);
            this.Controls.Add(this.N2);
            this.Controls.Add(this.I2);
            this.Controls.Add(this.B2);
            this.Controls.Add(this.O1);
            this.Controls.Add(this.G1);
            this.Controls.Add(this.N1);
            this.Controls.Add(this.I1);
            this.Controls.Add(this.B1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Sheet";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Bingo Card";
            this.Load += new System.EventHandler(this.Sheet_Load);
            ((System.ComponentModel.ISupportInitialize)(this.sheetclipbtn)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button B1;
        private Button I1;
        private Button N1;
        private Button G1;
        private Button O1;
        private Button O2;
        private Button G2;
        private Button N2;
        private Button I2;
        private Button B2;
        private Button O3;
        private Button G3;
        private Button N3;
        private Button I3;
        private Button B3;
        private Button O4;
        private Button G4;
        private Button N4;
        private Button I4;
        private Button B4;
        private Button O5;
        private Button G5;
        private Button N5;
        private Button I5;
        private Button B5;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button9;
        private Button button10;
        private Label currentbingoslbl;
        private Label label1;
        private PictureBox sheetclipbtn;
        private Label copyseedlbl;
        private TextBox seedtxtbx;
    }
}